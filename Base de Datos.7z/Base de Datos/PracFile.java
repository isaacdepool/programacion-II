/* Crear un programa que genere una agenda electronica, la misma debe guardar:
       Nombre y Apellido
       Telefono Habitacion
       Telefono Oficina
       Telefono Celular
   Utilizar un archivo.txt para guardar los datos
*/
