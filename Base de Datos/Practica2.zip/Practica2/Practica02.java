/* Crear un programa que permita generar una agenda electronica con los siguientes datos:
   NOMBRE					(Obligado)
   APELLIDO	    			(Obligado)
   Fecha de Nacimiento 		(Opcional)
   Telefono Oficina			(Opcional)	|
   Telefono Celular			(Opcional)  |  => (Obligatorio por lo menos 1)
   Telefono Casa			(Opcional)  |
*/
